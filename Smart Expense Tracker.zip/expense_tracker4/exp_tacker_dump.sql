DROP TABLE IF EXISTS `budgets`;
CREATE TABLE `budgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `category_id` int NOT NULL,
  `period` enum('weekly','monthly') NOT NULL,
  `amount_limit` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `limit_amount` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `idx_budgets_user` (`user_id`),
  CONSTRAINT `budgets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `budgets_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `budgets` WRITE;
INSERT INTO `budgets` VALUES (1,2,1,'monthly',500.00,'2025-07-03 21:57:09',NULL),(4,4,9,'monthly',1200.00,'2025-07-07 00:11:14',NULL),(5,4,10,'monthly',5000.00,'2025-07-07 00:11:23',NULL),(6,4,11,'monthly',2000.00,'2025-07-07 00:11:30',NULL),(7,4,12,'monthly',30000.00,'2025-07-07 00:11:39',NULL),(8,4,13,'monthly',15000.00,'2025-07-07 00:11:47',NULL);
UNLOCK TABLES;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('expense','income') DEFAULT 'expense',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `categories` WRITE;
INSERT INTO `categories` VALUES (1,2,'Food & Dining','expense','2025-07-03 10:56:41'),(2,2,'Transportation','expense','2025-07-03 10:57:09'),(3,2,'Utilities','expense','2025-07-03 10:57:28'),(4,2,'Entertainment','expense','2025-07-03 10:58:03'),(5,2,'Shopping','expense','2025-07-03 10:58:15'),(9,4,'Food ','expense','2025-07-07 00:00:04'),(10,4,'Travelling','expense','2025-07-07 00:00:10'),(11,4,'Entertainment','expense','2025-07-07 00:00:18'),(12,4,'Education','expense','2025-07-07 00:00:29'),(13,4,'Shopping','expense','2025-07-07 00:00:44');
UNLOCK TABLES;

DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `category_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` text,
  `expense_date` date NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_expenses_user_date` (`user_id`,`expense_date`),
  KEY `idx_expenses_category` (`category_id`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `expenses` WRITE;
INSERT INTO `expenses` VALUES (1,2,1,200.00,'Expenses related to meals, groceries, restaurants, and cafes.','2025-07-03','2025-07-03 11:13:27'),(2,2,5,3000.00,'Purchases of clothing, accessories, electronics, or personal items.\r\n\r\n','2025-07-01','2025-07-03 11:14:21'),(5,4,9,200.00,'Food & Drinks','2025-07-02','2025-07-07 00:24:57'),(6,4,12,15000.00,'Education Purpose','2025-06-27','2025-07-07 00:25:31'),(7,4,13,3000.00,'Shopping','2025-07-06','2025-07-07 00:26:16'),(8,4,10,1000.00,'Travelling','2025-07-01','2025-07-07 00:26:45'),(9,4,11,700.00,'Entertainment','2025-07-04','2025-07-07 00:27:15');
UNLOCK TABLES;

DROP TABLE IF EXISTS `income`;
CREATE TABLE `income` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `income_date` date NOT NULL,
  `note` text,
  `currency` varchar(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `income_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `income` WRITE;
INSERT INTO `income` VALUES (1,2,75000.00,'2025-07-02','My July Month Salary Added.','GBP','2025-07-06 15:48:51'),(2,4,75000.00,'2025-07-01','My July Month Salary.','GBP','2025-07-06 18:13:41');
UNLOCK TABLES;

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `message` text NOT NULL,
  `type` enum('alert','reminder','summary') NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`,`is_read`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `notifications` WRITE;

UNLOCK TABLES;

DROP TABLE IF EXISTS `otp_rec`;

CREATE TABLE `otp_rec` (
  `otp_id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `expires_at` datetime NOT NULL,
  `status` enum('unused','used') DEFAULT 'unused',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`otp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `otp_rec` WRITE;
INSERT INTO `otp_rec` VALUES (1,'venkykambhampati445@gmail.com','361232','2025-07-06 22:21:15','unused','2025-07-06 22:16:15'),(2,'venkykambhampati445@gmail.com','734118','2025-07-06 22:21:18','unused','2025-07-06 22:16:18'),(3,'venkykambhampati445@gmail.com','985838','2025-07-06 22:28:52','unused','2025-07-06 22:23:52'),(4,'venkykambhampati445@gmail.com','348356','2025-07-06 22:31:45','unused','2025-07-06 22:26:45'),(5,'venkykambhampati445@gmail.com','523448','2025-07-06 22:37:00','unused','2025-07-06 22:32:00'),(6,'lakshmikambhampati445@gmail.com','607515','2025-07-06 23:26:48','unused','2025-07-06 23:21:48'),(7,'lakshmikambhampati445@gmail.com','463392','2025-07-07 07:12:11','unused','2025-07-07 07:07:11'),(8,'venkykambhampati445@gmail.com','926784','2025-07-07 10:24:07','unused','2025-07-07 10:19:07');
UNLOCK TABLES;

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `users` WRITE;

INSERT INTO `users` VALUES (2,'Varshitha','varshitha@gmail.com','$2b$12$MUE9IsSqoX5TdXfu6qdY9.V/0y445qI5hCSMJh1QbkQzfufY2ZozK','4464465313','female','1998-05-15','profileimg1.jpg','2025-07-06 19:55:31',1,'2025-07-02 15:04:04'),(3,'Lakshmi ','venkykambhampati445@gmail.com','$2b$12$kxzybzQrl9/O3JC4a.yfL.mkCVJT1Qq8sZrMO.7O5FTaTRc7n6qU2','9821547622','female','1999-10-17','profileimg1.jpg','2025-07-07 10:20:10',1,'2025-07-06 22:05:59'),(4,'Lakshmi Kambhampati','lakshmikambhampati445@gmail.com','$2b$12$4BAmVk/2295B7792EmoYZeUBnEToqNjNXvMgfnl8GwHdgo6IwcYvq','9821547845','female','1992-11-12','profileimg1.jpg','2025-07-07 16:10:35',1,'2025-07-06 23:21:40'),(5,'Varshitha','varshitha123@gmail.com','$2b$12$LJvWNJFHmJ5xMGxzhAKSbuBYU60Pf2IMh9vBSfFmo07tluWdN2Pmm','4464465313','female','1999-12-16','profileimg1.jpg','2025-07-07 10:10:39',1,'2025-07-07 06:59:16');
UNLOCK TABLES;
