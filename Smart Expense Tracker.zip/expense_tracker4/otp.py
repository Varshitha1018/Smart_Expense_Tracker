import random
from datetime import datetime, timedelta
import mysql.connector
mydb=mysql.connector.connect(host='localhost',user='root',password='your_db_password',db='exp_tracker')


def genotp():
    return str(random.randint(100000, 999999)) 

def generate_otp(email):
    cursor = mydb.cursor(buffered=True)
    
    cursor.execute("DELETE FROM otp_rec WHERE email = %s AND status = 'unused'", (email,))
    mydb.commit()
    otp = genotp()
    expires_at = datetime.now() + timedelta(minutes=10)

    cursor.execute("""
        INSERT INTO otp_rec (email, otp, expires_at, status)
        VALUES (%s, %s, %s, 'unused')
    """, (email, otp, expires_at))
    mydb.commit()
    return otp
