from flask import Flask, render_template, url_for, redirect, flash, request, session, jsonify 
from itsdangerous import URLSafeTimedSerializer
from flask_session import Session 
from flask_bcrypt import Bcrypt
from otp import generate_otp
from cmail import sendmail
import re
import string
import random
import mysql.connector
from datetime import datetime, timedelta
from datetime import date
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'secret'
bcrypt = Bcrypt(app)

mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    password='your_db_password',
    database='exp_tracker'
)

@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('user_dashboard'))
    return render_template('welcome.html')

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('full_name')
        email = request.form.get('email')
        password = request.form.get('password')
        phone = request.form.get('phone_number')
        gender = request.form.get('gender')

        dob_day = request.form.get('dob_day')
        dob_month = request.form.get('dob_month')
        dob_year = request.form.get('dob_year')
        dob = None
        if dob_day and dob_month and dob_year:
            try:
                dob = datetime.strptime(f"{dob_year}-{dob_month}-{dob_day}", "%Y-%m-%d")
            except:
                flash('Invalid date of birth selected.', 'danger')
                return redirect(url_for('register'))

        image_file = request.files.get('profile_image')
        profile_image = None

        if image_file and allowed_file(image_file.filename):
            filename = secure_filename(image_file.filename)
            os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image_file.save(filepath)
            profile_image = filename

        if not name or not email or not password:
            flash('Please fill in all required fields.', 'danger')
            return redirect(url_for('register'))

        cursor = mydb.cursor()
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        if cursor.fetchone():
            flash('Email already registered.', 'danger')
            cursor.close()
            return redirect(url_for('register'))

        password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

        cursor.execute("""
            INSERT INTO users (full_name, email, password_hash, phone_number, gender, date_of_birth, profile_image, last_login, is_active, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, TRUE, NOW())
        """, (name, email, password_hash, phone, gender, dob, profile_image, None))

        mydb.commit()
        cursor.close()

        flash('Registration successful! You can now login.', 'success')
        return redirect(url_for('login'))

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        cursor = mydb.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()

        try:
            if user and bcrypt.check_password_hash(user['password_hash'], password):
                cursor = mydb.cursor()
                cursor.execute("UPDATE users SET last_login = NOW() WHERE id = %s", (user['id'],))
                mydb.commit()
                cursor.close()

                session['user_id'] = user['id']
                session['user_name'] = user['full_name']
                flash('Login successful!', 'success')
                return redirect(url_for('user_dashboard'))
            else:
                flash('Invalid email or password.', 'danger')
        except ValueError:
            flash("Corrupted password detected. Please reset your password.", "danger")
            return redirect(url_for('update_password'))

    return render_template('login.html')

@app.route('/update_profile', methods=['GET', 'POST'])
def update_profile():
    user_id = session.get('user_id')
    if not user_id:
        flash('You must be logged in to update your profile.', 'danger')
        return redirect(url_for('login'))

    cursor = mydb.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()

    if request.method == 'POST':
        full_name = request.form.get('full_name')
        phone_number = request.form.get('phone_number')
        gender = request.form.get('gender')
        date_of_birth_str = request.form.get('date_of_birth')
        profile_image = user['profile_image']

        date_of_birth = None
        if date_of_birth_str:
            try:
                date_of_birth = datetime.strptime(date_of_birth_str, "%Y-%m-%d").date()
            except ValueError:
                flash('Invalid date format.', 'danger')
                return redirect(url_for('update_profile'))

        image_file = request.files.get('profile_image')
        if image_file and image_file.filename:
            if allowed_file(image_file.filename):
                filename = secure_filename(image_file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
                image_file.save(filepath)
                profile_image = filename
            else:
                flash('Invalid image file.', 'danger')
                return redirect(url_for('update_profile'))

        update_query = """
            UPDATE users
            SET full_name = %s,
                phone_number = %s,
                gender = %s,
                date_of_birth = %s,
                profile_image = %s
            WHERE id = %s
        """
        cursor.execute(update_query, (
            full_name,
            phone_number,
            gender,
            date_of_birth,
            profile_image,
            user_id
        ))
        mydb.commit()
        cursor.close()

        flash('Profile updated successfully!', 'success')
        return redirect(url_for('update_profile'))

    cursor.close()
    return render_template('update_profile.html', user=user)

@app.route('/user_dashboard')
def user_dashboard():
    user_id = session.get('user_id')
    cursor = mydb.cursor(dictionary=True)

    cursor.execute("SELECT COALESCE(SUM(amount), 0) as total_income FROM income WHERE user_id = %s", (user_id,))
    total_income = cursor.fetchone()['total_income']

    cursor.execute("SELECT COALESCE(SUM(amount), 0) as total_expenses FROM expenses WHERE user_id = %s", (user_id,))
    total_expenses = cursor.fetchone()['total_expenses']

    total_balance = total_income - total_expenses
    savings = total_balance

    cursor.execute("""
        SELECT DATE(income_date) as date, SUM(amount) as amount 
        FROM income 
        WHERE user_id = %s AND MONTH(income_date) = MONTH(CURRENT_DATE()) 
        GROUP BY DATE(income_date)
    """, (user_id,))
    income_data = cursor.fetchall()

    cursor.execute("""
        SELECT DATE(expense_date) as date, SUM(amount) as amount 
        FROM expenses 
        WHERE user_id = %s AND MONTH(expense_date) = MONTH(CURRENT_DATE()) 
        GROUP BY DATE(expense_date)
    """, (user_id,))
    expense_data = cursor.fetchall()

    income_dict = {str(row['date']): row['amount'] for row in income_data}
    expense_dict = {str(row['date']): row['amount'] for row in expense_data}
    all_dates = sorted(set(income_dict.keys()).union(expense_dict.keys()))

    chart_labels = all_dates
    chart_income = [income_dict.get(date, 0) for date in all_dates]
    chart_expenses = [expense_dict.get(date, 0) for date in all_dates]

    show_line_chart = any(chart_income) or any(chart_expenses)

    cursor.execute("""
        SELECT b.amount_limit, c.name, (
            SELECT COALESCE(SUM(amount), 0) 
            FROM expenses 
            WHERE user_id = %s AND category_id = b.category_id AND MONTH(expense_date) = MONTH(CURRENT_DATE())
        ) as used 
        FROM budgets b 
        JOIN categories c ON b.category_id = c.id 
        WHERE b.user_id = %s
    """, (user_id, user_id))
    budgets = cursor.fetchall()

    color_palette = ["bg-red-500", "bg-blue-500", "bg-green-500", "bg-yellow-500", "bg-purple-500"]
    assigned_colors = {}
    for i, budget in enumerate(budgets):
        name = budget['name']
        assigned_colors[name] = color_palette[i % len(color_palette)]
        budget['color_class'] = assigned_colors[name]
        used = float(budget['used'])
        limit = float(budget['amount_limit'])
        budget['used'] = int(used) if used.is_integer() else round(used, 2)
        budget['amount_limit'] = int(limit) if limit.is_integer() else round(limit, 2)
        budget['percent_used'] = int((used / limit) * 100) if limit else 0

    cursor.execute("""
        SELECT e.id, e.amount, e.expense_date, e.description, c.name AS category_name 
        FROM expenses e 
        JOIN categories c ON e.category_id = c.id 
        WHERE e.user_id = %s 
        ORDER BY e.expense_date DESC 
        LIMIT 5
    """, (user_id,))
    transactions = cursor.fetchall()

    cursor.execute("""
        SELECT c.name AS category, SUM(e.amount) AS total 
        FROM expenses e 
        JOIN categories c ON e.category_id = c.id 
        WHERE e.user_id = %s 
        GROUP BY c.name
    """, (user_id,))
    category_data = cursor.fetchall()
    show_donut_chart = bool(category_data)

    total_category_expense = sum(row['total'] for row in category_data)
    default_colors = ["#ef4444", "#3b82f6", "#10b981", "#f59e0b", "#8b5cf6"]
    chart_data, legend_data = [], []
    for i, row in enumerate(category_data):
        color = default_colors[i % len(default_colors)]
        category, amount = row['category'], row['total']
        percent = round((amount / total_category_expense) * 100) if total_category_expense else 0
        chart_data.append({'label': category, 'value': amount, 'color': color})
        legend_data.append({'category': category, 'percent': percent, 'color': color})

    cursor.close()
    has_data = bool(chart_income or chart_expenses or chart_data or transactions or budgets)

    return render_template("user_dashboard2.html",
        total_balance=round(total_balance, 2),
        monthly_income=round(total_income, 2),
        monthly_expenses=round(total_expenses, 2),
        savings=round(savings, 2),
        chart_labels=chart_labels,
        chart_income=chart_income,
        chart_expenses=chart_expenses,
        budgets=budgets,
        transactions=transactions,
        chart_data=chart_data,
        legend_data=legend_data,
        show_line_chart=show_line_chart,
        show_donut_chart=show_donut_chart,
        currency_symbol='\u00a3',
        has_data=has_data 
    )

@app.route('/forget_password',methods=['GET','POST'])
def forget_password():
    if request.method == 'POST':
        email = request.form.get('email')
        if not email:
            flash('Please enter an email.', 'error')
            return render_template('forgotpassword.html')  
        cursor = mydb.cursor(buffered=True)
        cursor.execute("SELECT COUNT(*) FROM users WHERE email = %s", (email,))
        user_record = cursor.fetchone()[0]
        cursor.close()
        if user_record:
            otp = generate_otp(email)  

            try:
                cursor = mydb.cursor(dictionary=True)
                cursor.execute('INSERT INTO otp_rec (email, otp, expires_at) VALUES (%s, %s, NOW() + INTERVAL 5 MINUTE)',(email, otp))
                mydb.commit()
            except Exception as e:
                mydb.rollback()
                flash('Failed to store OTP. Please try again later.', 'error')
                return render_template('forgotpassword.html')
            finally:
                cursor.close()
            session['email'] = email
            subject = 'Emp_OTP Verification'
            body = f"Dear User,\n\nYour OTP for validation is: {otp}\n\nPlease use this OTP within 5 minutes."

            try:
                sendmail(to=email, subject=subject, body=body)
                flash('OTP has been sent to your email. Please check it.', 'success')
                return redirect(url_for('otp_verify'))
            except Exception as e:
                flash('Failed to send OTP email. Please try again later.', 'error')
                return render_template('forgotpassword.html')
        else:
            flash('Email not found. Please try again or contact support.', 'error')
            return render_template('forgotpassword.html')

    return render_template('forgotpassword.html')

@app.route('/otp_verify', methods=['GET', 'POST'])
def otp_verify():
    email = session.get('email')
    if request.method == 'POST':
        otp_parts = [request.form.get(f'otp{i}') for i in range(1, 7)]
        
        if not all(otp_parts):
            flash("Please enter the complete 6-digit OTP.", "error")
            return redirect(url_for('otp_verify'))

        entered_otp = ''.join(otp_parts)

        cursor = mydb.cursor(buffered=True)
        cursor.execute("SELECT otp FROM otp_rec WHERE expires_at > NOW() ORDER BY otp_id DESC LIMIT 1")
        result = cursor.fetchone()
        cursor.close()

        if result:
            db_otp = result[0]
            if db_otp == entered_otp:
                flash("OTP Verified. Please set your new password.", "success")
                return redirect(url_for('update_password'))  
            else:
                flash("Invalid OTP. Please try again.", "error")
                return redirect(url_for('otp_verify'))
        else:
            flash("No valid OTP found or OTP expired. Please request a new OTP.", "error")
            return redirect(url_for('forget_password'))

    return render_template('otp_verify.html')

@app.route('/update_password', methods=['GET', 'POST'])
def update_password():
    email = session.get('email')  
    if not email:
        flash("Session expired or unauthorized access. Please login again.", "error")
        return redirect(url_for('login'))

    if request.method == 'POST':
        new_pwd = request.form.get('new_password')
        cnfrm_pwd = request.form.get('confirm_password')

        if not new_pwd or not cnfrm_pwd:
            flash("Both fields are required.", "error")
            return render_template('update_password.html', email=email)

        if new_pwd != cnfrm_pwd:
            flash("The New Password and Confirm Password do not match. Try again.", "error")
            return redirect(url_for('update_password'))
        hashed_password = bcrypt.generate_password_hash(new_pwd).decode('utf-8')

        try:
            cursor = mydb.cursor()
            cursor.execute('UPDATE users SET password_hash = %s WHERE email = %s', (hashed_password, email))
            mydb.commit()
            cursor.close()

            session.pop('email', None)
            flash("Your password has been updated successfully. Please login.", "success")
            return redirect(url_for('login'))

        except Exception as e:
            print("DB error:", e)
            flash("An error occurred while updating the password. Please try again.", "error")
            return render_template('update_password.html', email=email)

    return render_template('update_password.html', email=email)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.context_processor
def inject_user_info():
    user_id = session.get('user_id')
    if not user_id:
        return {}
    cursor = mydb.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()
    return {'user_info': user}

@app.route('/add_income', methods=['GET', 'POST'])
def add_income():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))

    currencies = [
        ('USD', '$ - US Dollar'),
        ('EUR', '€ - Euro'),
        ('GBP', '£ - British Pound'),
        ('AUD', 'A$ - Australian Dollar'),
        ('CAD', 'C$ - Canadian Dollar'),
        ('INR', '₹ - Indian Rupee'),
        ('JPY', '¥ - Japanese Yen'),
        ('CNY', '¥ - Chinese Yuan'),
        ('SGD', 'S$ - Singapore Dollar'),
        ('CHF', 'CHF - Swiss Franc')
    ]

    if request.method == 'POST':
        try:
            amount = float(request.form['amount'])
            income_date = request.form['income_date']
            note = request.form.get('note', '')
            currency = request.form['currency']

            cur = mydb.cursor()
            cur.execute("""
                INSERT INTO income (user_id, amount, income_date, note, currency)
                VALUES (%s, %s, %s, %s, %s)
            """, (user_id, amount, income_date, note, currency))
            mydb.commit()

            flash('Income added successfully!', 'success')
            return redirect(url_for('add_income'))
        except Exception as e:
            mydb.rollback()
            flash(f'Failed to add income: {e}', 'danger')
            return redirect(url_for('add_income'))

    return render_template('add_income.html', currencies=currencies)

@app.route('/add_expense', methods=['GET', 'POST'])
def add_expense():
    user_id = session.get('user_id')  
    if not user_id:
        return redirect(url_for('login'))

    cur = mydb.cursor(dictionary=True)

    cur.execute("SELECT id, name FROM categories WHERE user_id = %s OR user_id IS NULL", (user_id,))
    categories = cur.fetchall()

    if request.method == 'POST':
        category_id = request.form.get('category_id')
        amount = float(request.form.get('amount'))
        description = request.form.get('description')
        expense_date = request.form.get('expense_date')

        cur.execute("SELECT name FROM categories WHERE id = %s", (category_id,))
        cat_row = cur.fetchone()
        category_name = cat_row['name'] if cat_row else "Unknown"

        cur.execute("""
            SELECT amount_limit 
            FROM budgets 
            WHERE user_id = %s AND category_id = %s AND period = 'monthly'
        """, (user_id, category_id))
        budget_row = cur.fetchone()
        budget_limit = float(budget_row['amount_limit']) if budget_row else None

        cur.execute("""
            SELECT COALESCE(SUM(amount), 0) AS total_spent 
            FROM expenses 
            WHERE user_id = %s AND category_id = %s 
              AND MONTH(expense_date) = MONTH(CURDATE()) 
              AND YEAR(expense_date) = YEAR(CURDATE())
        """, (user_id, category_id))
        total_spent_row = cur.fetchone()
        total_spent = float(total_spent_row['total_spent']) if total_spent_row else 0

        new_total = total_spent + amount

        cur.execute("""
            INSERT INTO expenses (user_id, category_id, amount, description, expense_date)
            VALUES (%s, %s, %s, %s, %s)
        """, (user_id, category_id, amount, description, expense_date))
        mydb.commit()

        if budget_limit is not None and new_total > budget_limit:
            message = f"⚠ Budget exceeded for '{category_name}': Limit ₹{budget_limit}, Spent ₹{new_total}"
            cur.execute("""
                INSERT INTO notifications (user_id, category, message)
                VALUES (%s, %s, %s)
            """, (user_id, category_name, message))
            mydb.commit()

            flash('Expense added, but budget exceeded!', 'warning')
        else:
            flash('Expense added successfully!', 'success')

        cur.close()
        return redirect(url_for('transactions'))

    cur.close()
    return render_template('add_expense.html', categories=categories)


@app.route('/transactions')
def transactions():
    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    cursor = mydb.cursor(dictionary=True)

    query = """
        SELECT e.id, c.name as category_name, e.amount, e.description, e.expense_date, e.created_at
        FROM expenses e
        JOIN categories c ON e.category_id = c.id
        WHERE e.user_id = %s
        ORDER BY e.expense_date DESC
    """
    cursor.execute(query, (user_id,))
    expenses = cursor.fetchall()

    return render_template('transactions.html', expenses=expenses)

@app.route('/delete_transaction/<int:expense_id>', methods=['POST'])
def delete_transaction(expense_id):
    user_id = session.get('user_id')
    if not user_id:
        flash("You must be logged in to perform this action.", "warning")
        return redirect(url_for('login'))

    try:
        cur = mydb.cursor()
        cur.execute("SELECT * FROM expenses WHERE id = %s AND user_id = %s", (expense_id, user_id))
        expense = cur.fetchone()

        if not expense:
            flash("Transaction not found or unauthorized access.", "danger")
        else:
            cur.execute("DELETE FROM expenses WHERE id = %s AND user_id = %s", (expense_id, user_id))
            mydb.commit()
            flash("Transaction deleted successfully.", "success")

    except Exception as e:
        mydb.rollback()
        flash(f"Error deleting transaction: {e}", "danger")

    return redirect(url_for('transactions'))

@app.route('/categories', methods=['GET', 'POST'])
def categories():
    user_id = session['user_id']
    cur = mydb.cursor(dictionary=True)

    if request.method == 'POST':
        name = request.form['name']
        type = request.form['type']
        cur.execute("INSERT INTO categories (user_id, name, type) VALUES (%s, %s, %s)", (user_id, name, type))
        mydb.commit()
        return redirect(url_for('categories'))

    cur.execute("SELECT * FROM categories WHERE user_id IS NULL OR user_id = %s", (user_id,))
    categories = cur.fetchall()
    return render_template('category.html', categories=categories)


@app.route('/add_category', methods=['POST'])
def add_category():
    user_id = session['user_id']
    name = request.form['name']
    type_ = request.form['type']
    cur = mydb.cursor()
    cur.execute("INSERT INTO categories (user_id, name, type) VALUES (%s, %s, %s)", (user_id, name, type_))
    mydb.commit()
    return redirect('/categories')

@app.route('/delete_category/<int:category_id>', methods=['POST'])
def delete_category(category_id):
    user_id = session.get('user_id')
    if not user_id:
        flash("You must be logged in to perform this action.", "warning")
        return redirect(url_for('login'))

    try:
        cur = mydb.cursor()
        cur.execute("SELECT * FROM categories WHERE id = %s AND user_id = %s", (category_id, user_id))
        category = cur.fetchone()

        if not category:
            flash("Category not found or unauthorized access.", "danger")
            return redirect('/categories') 
        cur.execute("DELETE FROM categories WHERE id = %s AND user_id = %s", (category_id, user_id))
        mydb.commit()
        flash("Category deleted successfully!", "success")
    except Exception as e:
        mydb.rollback()
        flash(f"Error deleting category: {e}", "danger")

    return redirect('/categories') 

@app.route('/budgets', methods=['GET', 'POST'])
def budgets():
    user_id = session['user_id']
    cur = mydb.cursor(dictionary=True)

    if request.method == 'POST':
        category_id = request.form['category_id']
        period = request.form['period']
        amount_limit = request.form['amount_limit']
        cur.execute("""
            INSERT INTO budgets (user_id, category_id, period, amount_limit)
            VALUES (%s, %s, %s, %s)
        """, (user_id, category_id, period, amount_limit))
        mydb.commit()
        return redirect(url_for('budgets'))

    cur.execute("SELECT * FROM categories WHERE user_id IS NULL OR user_id = %s", (user_id,))
    categories = cur.fetchall()

    cur.execute("""
        SELECT budgets.*, categories.name AS category_name
        FROM budgets
        JOIN categories ON budgets.category_id = categories.id
        WHERE budgets.user_id = %s
    """, (user_id,))
    user_budgets = cur.fetchall()

    return render_template('budgets.html', categories=categories, budgets=user_budgets)

@app.route('/delete_budget/<int:budget_id>', methods=['POST'])
def delete_budget(budget_id):
    user_id = session.get('user_id')
    if not user_id:
        flash("You must be logged in to perform this action.", "warning")
        return redirect(url_for('login'))

    cur = mydb.cursor(dictionary=True)

    try:
        cur.execute("SELECT * FROM budgets WHERE id = %s AND user_id = %s", (budget_id, user_id))
        budget = cur.fetchone()

        if not budget:
            flash("Budget not found or unauthorized access.", "danger")
        else:
            cur.execute("DELETE FROM budgets WHERE id = %s AND user_id = %s", (budget_id, user_id))
            mydb.commit()
            flash("Budget deleted successfully!", "success")

    except Exception as e:
        mydb.rollback()
        flash(f"Error deleting budget: {e}", "danger")

    cur.execute("SELECT * FROM categories WHERE user_id IS NULL OR user_id = %s", (user_id,))
    categories = cur.fetchall()

    cur.execute("""
        SELECT budgets.*, categories.name AS category_name
        FROM budgets
        JOIN categories ON budgets.category_id = categories.id
        WHERE budgets.user_id = %s
    """, (user_id,))
    user_budgets = cur.fetchall()

    return render_template('budgets.html', categories=categories, budgets=user_budgets)

@app.route('/reports')
def reports():
    user_id = session.get('user_id')
    cursor = mydb.cursor(dictionary=True)

    cursor.execute("SELECT SUM(amount) as total_spent FROM expenses WHERE user_id = %s", (user_id,))
    total_spent = cursor.fetchone()['total_spent'] or 0

    cursor.execute("SELECT SUM(amount) FROM income WHERE user_id = %s", (user_id,))
    total_income = cursor.fetchone()['SUM(amount)'] or 0

    total_balance = total_income - total_spent
    savings = total_balance

    balance_change = 12.5
    income_change = 5.2
    expenses_change = 3.8
    savings_change = 8.7

    cursor.execute("""
        SELECT c.name as category, SUM(e.amount) as total
        FROM expenses e
        JOIN categories c ON e.category_id = c.id
        WHERE e.user_id = %s
        GROUP BY c.name
    """, (user_id,))
    pie_data = cursor.fetchall()

    cursor.execute("""
        SELECT DATE(expense_date) as expense_date, SUM(amount) as total
        FROM expenses
        WHERE user_id = %s
        GROUP BY DATE(expense_date)
        ORDER BY expense_date DESC
        LIMIT 7
    """, (user_id,))
    bar_data = cursor.fetchall()

    cursor.execute("""
        SELECT DATE_FORMAT(expense_date, '%%Y-%%m') as month, SUM(amount) as total
        FROM expenses
        WHERE user_id = %s
        GROUP BY month
        ORDER BY month
    """, (user_id,))
    line_data = cursor.fetchall()

    cursor.execute("""
        SELECT c.name as category,
            0 as income,
            COALESCE(SUM(e.amount), 0) as expense
        FROM categories c
        LEFT JOIN expenses e ON c.id = e.category_id AND e.user_id = %s
        GROUP BY c.name
    """, (user_id,))
    radar_data = cursor.fetchall()

    show_pie_chart = bool(pie_data)
    show_bar_chart = bool(bar_data)
    show_line_chart = bool(line_data)
    show_radar_chart = any(item['income'] > 0 or item['expense'] > 0 for item in radar_data)

    cursor.close()

    return render_template('reports.html',
        total_spent=total_spent,
        monthly_income=total_income,
        monthly_expenses=total_spent,
        total_balance=total_balance,
        savings=savings,
        balance_change=balance_change,
        income_change=income_change,
        expenses_change=expenses_change,
        savings_change=savings_change,
        pie_data=pie_data,
        bar_data=bar_data[::-1],    
        line_data=line_data,
        radar_data=radar_data,
        show_pie_chart=show_pie_chart,
        show_bar_chart=show_bar_chart,
        show_line_chart=show_line_chart,
        show_radar_chart=show_radar_chart,
        currency_symbol='£'
    )

def check_and_notify(user_id, category, amount):
    cursor = mydb.cursor(dictionary=True)

    cursor.execute("SELECT SUM(amount) AS total_income FROM income WHERE user_id = %s", (user_id,))
    income = cursor.fetchone()['total_income'] or 0

    cursor.execute("SELECT limit_amount FROM budgets WHERE user_id = %s AND category = %s", (user_id, category))
    row = cursor.fetchone()
    if not row:
        cursor.close()
        return  

    category_limit = row['limit_amount']

    cursor.execute("SELECT SUM(amount) AS total_spent FROM expenses WHERE user_id = %s AND category = %s", (user_id, category))
    total_spent = cursor.fetchone()['total_spent'] or 0

    if total_spent > category_limit:
        cursor.execute("""
            SELECT id FROM notifications
            WHERE user_id = %s AND category = %s AND is_read = FALSE
        """, (user_id, category))
        if not cursor.fetchone():
            message = f"Warning! Your spending in '{category}' has exceeded your set budget."
            cursor.execute("""
                INSERT INTO notifications (user_id, category, message)
                VALUES (%s, %s, %s)
            """, (user_id, category, message))
            mydb.commit()

    cursor.close()

@app.route('/notifications')
def notifications():
    user_id = session.get('user_id')
    if not user_id:
        flash('Please login to view notifications.', 'danger')
        return redirect(url_for('login'))

    cursor = mydb.cursor(dictionary=True)
    cursor.execute("""
        SELECT * FROM notifications
        WHERE user_id = %s AND is_read = FALSE
        ORDER BY created_at DESC
    """, (user_id,))
    notifications = cursor.fetchall()
    cursor.close()
    return render_template('notifications.html', notifications=notifications)

@app.route('/remove_notification/<int:notification_id>', methods=['POST'])
def remove_notification(notification_id):
    user_id = session.get('user_id')
    cursor = mydb.cursor()
    cursor.execute("""
        UPDATE notifications
        SET is_read = TRUE
        WHERE id = %s AND user_id = %s
    """, (notification_id, user_id))
    mydb.commit()
    cursor.close()
    return redirect(url_for('notifications'))

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/help')
def help():
    return render_template('help.html')

@app.route('/privacy-policy')
def privacy_policy():
    return render_template('privacy_policy.html')

@app.route('/terms')
def terms_conditions():
    return render_template('terms_conditions.html')

@app.route('/user-guide')
def user_guide():
    return render_template('user_guide.html')

@app.route('/budget-tips')
def budget_tips():
    return render_template('budget_tips.html')

@app.route('/company-overview')
def company_overview():
    return render_template('company_overview.html')

app.run(debug=True)